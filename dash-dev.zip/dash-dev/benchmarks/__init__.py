"""Dash performance benchmark harness."""
