/**
 * Client for communicating with the Dash WebSocket SharedWorker.
 */

import {getRendererId} from './rendererId';

/** Message types for worker communication */
export enum WorkerMessageType {
    CONNECT = 'connect',
    DISCONNECT = 'disconnect',
    CALLBACK_REQUEST = 'callback_request',
    GET_PROPS_RESPONSE = 'get_props_response',
    TAB_VISIBLE = 'tab_visible',
    CONNECTED = 'connected',
    DISCONNECTED = 'disconnected',
    CALLBACK_RESPONSE = 'callback_response',
    SET_PROPS = 'set_props',
    SET_PROPS_BATCH = 'set_props_batch',
    GET_PROPS_REQUEST = 'get_props_request',
    ERROR = 'error'
}

/** Callback response structure */
export interface CallbackResponse {
    status: 'ok' | 'prevent_update' | 'error';
    data?: Record<string, unknown>;
    message?: string;
    /** True for responses from a streaming callback */
    stream?: boolean;
    /** True on the terminal frame of a streamed callback */
    done?: boolean;
}

/** Set props message payload */
export interface SetPropsPayload {
    componentId: string;
    props: Record<string, unknown>;
}

/** Get props request payload */
export interface GetPropsRequestPayload {
    componentId: string;
    properties: string[];
    /** Optional location within each requested property. */
    path?: (string | number)[];
}

/** Pending callback request */
interface PendingRequest {
    resolve: (value: CallbackResponse) => void;
    reject: (error: Error) => void;
    /** Receives intermediate frames from a streaming callback */
    onFrame?: (data: Record<string, unknown>) => void;
}

/**
 * Client for the Dash WebSocket SharedWorker.
 */
class WorkerClient {
    private worker: SharedWorker | null = null;
    private rendererId: string;
    private pendingCallbacks: Map<string, PendingRequest> = new Map();
    private requestCounter = 0;
    private isConnected = false;
    private connectionPromise: Promise<void> | null = null;
    private connectionResolve: (() => void) | null = null;

    /** Callback when SET_PROPS message is received */
    public onSetProps: ((payload: SetPropsPayload) => void) | null = null;

    /** Callback when SET_PROPS_BATCH message is received */
    public onSetPropsBatch: ((payloads: SetPropsPayload[]) => void) | null =
        null;

    /** Callback when GET_PROPS_REQUEST message is received */
    public onGetPropsRequest:
        | ((requestId: string, payload: GetPropsRequestPayload) => void)
        | null = null;

    /** Callback when connection is established */
    public onConnected: (() => void) | null = null;

    /** Callback when connection is lost */
    public onDisconnected: ((reason?: string) => void) | null = null;

    /** Callback when an error occurs */
    public onError: ((message: string, code?: string) => void) | null = null;

    constructor() {
        this.rendererId = getRendererId();
    }

    /**
     * Initialize the worker connection.
     * @param workerUrl URL to the SharedWorker script
     * @param serverUrl WebSocket server URL
     * @param inactivityTimeout Optional inactivity timeout in ms
     * @param heartbeatInterval Optional heartbeat interval in ms
     */
    public async connect(
        workerUrl: string,
        serverUrl: string,
        inactivityTimeout?: number,
        heartbeatInterval?: number
    ): Promise<void> {
        if (this.worker) {
            // Already connected
            return;
        }

        // Create the SharedWorker
        this.worker = new SharedWorker(workerUrl, {
            name: 'dash-ws-worker'
        });

        // Set up message handling
        this.worker.port.onmessage = this.handleMessage.bind(this);

        // Create promise for connection
        this.connectionPromise = new Promise(resolve => {
            this.connectionResolve = resolve;
        });

        // Start the port
        this.worker.port.start();

        // Send connect message
        this.worker.port.postMessage({
            type: WorkerMessageType.CONNECT,
            rendererId: this.rendererId,
            payload: {
                serverUrl,
                inactivityTimeout,
                heartbeatInterval
            }
        });

        // Wait for connection
        await this.connectionPromise;
    }

    /**
     * Disconnect from the worker.
     */
    public disconnect(): void {
        if (this.worker) {
            this.worker.port.postMessage({
                type: WorkerMessageType.DISCONNECT,
                rendererId: this.rendererId
            });
            this.worker.port.close();
            this.worker = null;
        }
        this.isConnected = false;
        this.connectionPromise = null;
        this.connectionResolve = null;

        // Resolve pending callbacks with prevent_update so loading states clear
        for (const [, pending] of this.pendingCallbacks) {
            pending.resolve({status: 'prevent_update'});
        }
        this.pendingCallbacks.clear();
    }

    /**
     * Ensure the worker is connected, initiating connection if needed.
     * @param config The Dash config with websocket settings
     */
    public async ensureConnected(config: {
        websocket?: {
            url?: string;
            worker_url?: string;
            inactivity_timeout?: number;
            heartbeat_interval?: number;
        };
    }): Promise<void> {
        // Already connected
        if (this.isConnected) {
            return;
        }

        // Connection in progress, wait for it
        if (this.connectionPromise) {
            await this.connectionPromise;
            return;
        }

        // Need to initiate connection
        if (!config.websocket?.url || !config.websocket?.worker_url) {
            throw new Error('WebSocket config not available');
        }

        if (typeof SharedWorker === 'undefined') {
            throw new Error('SharedWorker not supported');
        }

        // Build WebSocket URL
        const wsProtocol =
            window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host;
        const wsUrl = `${wsProtocol}//${host}${config.websocket.url}`;

        await this.connect(
            config.websocket.worker_url,
            wsUrl,
            config.websocket.inactivity_timeout,
            config.websocket.heartbeat_interval
        );
    }

    /**
     * Send a callback request to the server via the worker.
     * @param payload The callback payload
     * @param onFrame Optional handler for intermediate frames from a
     *   streaming callback; the returned promise still resolves once with
     *   the terminal response.
     * @returns Promise that resolves with the callback response
     */
    public async sendCallback(
        payload: unknown,
        onFrame?: (data: Record<string, unknown>) => void
    ): Promise<CallbackResponse> {
        // Wait for initial connection if one is in progress
        if (this.connectionPromise && !this.isConnected) {
            await this.connectionPromise;
        }

        if (!this.worker) {
            throw new Error('Worker not connected');
        }

        const requestId = `${this.rendererId}-${++this.requestCounter}`;

        return new Promise((resolve, reject) => {
            this.pendingCallbacks.set(requestId, {resolve, reject, onFrame});

            this.worker!.port.postMessage({
                type: WorkerMessageType.CALLBACK_REQUEST,
                rendererId: this.rendererId,
                requestId,
                payload
            });
        });
    }

    /**
     * Send a get_props response back to the server.
     * @param requestId The request ID from the get_props request
     * @param props The property values
     */
    public sendGetPropsResponse(
        requestId: string,
        props: Record<string, unknown>
    ): void {
        if (!this.worker || !this.isConnected) {
            return;
        }

        this.worker.port.postMessage({
            type: WorkerMessageType.GET_PROPS_RESPONSE,
            rendererId: this.rendererId,
            requestId,
            payload: props
        });
    }

    /**
     * Check if the worker is connected.
     */
    public get connected(): boolean {
        return this.isConnected;
    }

    /**
     * Notify the worker that the tab is now visible.
     * This resets the inactivity timer to prevent timeout while user is viewing.
     */
    public notifyTabVisible(): void {
        if (this.worker && this.isConnected) {
            this.worker.port.postMessage({
                type: WorkerMessageType.TAB_VISIBLE,
                rendererId: this.rendererId
            });
        }
    }

    private handleMessage(event: MessageEvent): void {
        const message = event.data;

        switch (message.type) {
            case WorkerMessageType.CONNECTED:
                this.isConnected = true;
                if (this.connectionResolve) {
                    this.connectionResolve();
                    this.connectionResolve = null;
                }
                if (this.onConnected) {
                    this.onConnected();
                }
                break;

            case WorkerMessageType.DISCONNECTED:
                this.isConnected = false;
                // Resolve pending callbacks with prevent_update so loading states clear
                for (const [, pending] of this.pendingCallbacks) {
                    pending.resolve({status: 'prevent_update'});
                }
                this.pendingCallbacks.clear();
                if (this.onDisconnected) {
                    this.onDisconnected(message.payload?.reason);
                }
                break;

            case WorkerMessageType.CALLBACK_RESPONSE: {
                const requestId = message.requestId;
                const pending = this.pendingCallbacks.get(requestId);
                if (pending) {
                    const payload = message.payload;
                    if (
                        payload?.stream &&
                        !payload.done &&
                        payload.status === 'ok'
                    ) {
                        // Intermediate stream frame: deliver it and keep the
                        // request pending until the terminal frame arrives.
                        if (pending.onFrame) {
                            pending.onFrame(payload.data);
                        }
                        break;
                    }
                    this.pendingCallbacks.delete(requestId);
                    pending.resolve(payload);
                }
                break;
            }

            case WorkerMessageType.SET_PROPS:
                if (this.onSetProps) {
                    this.onSetProps(message.payload);
                }
                break;

            case WorkerMessageType.SET_PROPS_BATCH:
                if (this.onSetPropsBatch) {
                    this.onSetPropsBatch(message.payload);
                }
                break;

            case WorkerMessageType.GET_PROPS_REQUEST:
                if (this.onGetPropsRequest) {
                    this.onGetPropsRequest(message.requestId, message.payload);
                }
                break;

            case WorkerMessageType.ERROR:
                if (this.onError) {
                    this.onError(
                        message.payload?.message || 'Unknown error',
                        message.payload?.code
                    );
                }
                break;
        }
    }
}

// Singleton instance
let workerClientInstance: WorkerClient | null = null;

/**
 * Get the singleton WorkerClient instance.
 */
export function getWorkerClient(): WorkerClient {
    if (!workerClientInstance) {
        workerClientInstance = new WorkerClient();
    }
    return workerClientInstance;
}

/**
 * Check if WebSocket callbacks are globally enabled and supported.
 * @param config The Dash config
 */
export function isWebSocketEnabled(config: {
    websocket?: {enabled: boolean};
}): boolean {
    return !!(config.websocket?.enabled && typeof SharedWorker !== 'undefined');
}

/**
 * Check if WebSocket infrastructure is available (for per-callback websocket).
 * @param config The Dash config
 */
export function isWebSocketAvailable(config: {
    websocket?: {
        enabled?: boolean;
        url?: string;
        worker_url?: string;
        inactivity_timeout?: number;
    };
}): boolean {
    return !!(
        config.websocket?.url &&
        config.websocket?.worker_url &&
        typeof SharedWorker !== 'undefined'
    );
}
