import logging
import pytest
from dash import Dash, Input, Output, html, dcc, ctx


@pytest.mark.parametrize(
    "backend,fixture",
    [
        ("flask", "dash_duo"),
        ("fastapi", "dash_duo"),
        ("quart", "dash_duo_mp"),
    ],
)
def test_set_cookie_and_header(request, backend, fixture):
    dash_duo = request.getfixturevalue(fixture)
    app = Dash(__name__, backend=backend)
    app.layout = html.Div([html.Button("Set", id="btn"), html.Div(id="output")])

    @app.callback(Output("output", "children"), Input("btn", "n_clicks"))
    def set_cookie_and_header(n):
        if ctx.response:
            ctx.response.set_cookie("mycookie", "cookieval")
            ctx.response.set_header("X-My-Header", "HeaderVal")
            ctx.response.append_header("X-My-Header", "HeaderVal2")
            ctx.response.append_header("X-My-Header2", "HeaderVal3")
            ctx.response.set_header("X-My-Header2", "HeaderVal4")
        return f"Clicked {n}" if n else "Not clicked"

    dash_duo.start_server(app)
    dash_duo.driver.execute_script(
        """
        window._lastResponseHeaders = null;
        const origFetch = window.fetch;
        window.fetch = async function() {
            const response = await origFetch.apply(this, arguments);
            response.clone().headers.forEach((v, k) => {
                if (!window._lastResponseHeaders) window._lastResponseHeaders = {};
                window._lastResponseHeaders[k] = v;
            });
            return response;
        };
    """
    )

    dash_duo.find_element("#btn").click()
    dash_duo.wait_for_text_to_equal("#output", "Clicked 1")

    # Check cookie
    cookies = dash_duo.driver.get_cookies()
    assert any(c["name"] == "mycookie" and c["value"] == "cookieval" for c in cookies)

    headers = dash_duo.driver.execute_script("return window._lastResponseHeaders;")
    assert headers and headers["x-my-header"] == "HeaderVal, HeaderVal2"
    assert headers and headers["x-my-header2"] == "HeaderVal4"


@pytest.mark.parametrize(
    "backend,fixture,input_value",
    [
        ("fastapi", "dash_duo", "Hello FastAPI!"),
        ("quart", "dash_duo_mp", "Hello Quart!"),
    ],
)
def test_backend_basic_callback(request, backend, fixture, input_value):
    dash_duo = request.getfixturevalue(fixture)
    if backend == "fastapi":
        from fastapi import FastAPI

        server = FastAPI()
    else:
        import quart

        server = quart.Quart(__name__)
    app = Dash(__name__, server=server)
    app.layout = html.Div(
        [dcc.Input(id="input", value=input_value, type="text"), html.Div(id="output")]
    )

    @app.callback(Output("output", "children"), Input("input", "value"))
    def update_output(value):
        return f"You typed: {value}"

    dash_duo.start_server(app)
    dash_duo.wait_for_text_to_equal("#output", f"You typed: {input_value}")
    dash_duo.clear_input(dash_duo.find_element("#input"))
    dash_duo.find_element("#input").send_keys(f"{backend.title()} Test")
    dash_duo.wait_for_text_to_equal("#output", f"You typed: {backend.title()} Test")
    assert dash_duo.get_logs() == []


@pytest.mark.parametrize(
    "backend,fixture,start_server_kwargs",
    [
        (
            "fastapi",
            "dash_duo",
            {"debug": True, "reload": False, "dev_tools_ui": True},
        ),
        (
            "quart",
            "dash_duo_mp",
            {
                "debug": True,
                "use_reloader": False,
                "dev_tools_hot_reload": False,
            },
        ),
    ],
)
def test_backend_error_handling(request, backend, fixture, start_server_kwargs):
    dash_duo = request.getfixturevalue(fixture)
    app = Dash(__name__, backend=backend)
    app.layout = html.Div(
        [html.Button(id="btn", children="Error", n_clicks=0), html.Div(id="output")]
    )

    @app.callback(Output("output", "children"), Input("btn", "n_clicks"))
    def error_callback(n):
        if n and n > 0:
            return 1 / 0  # Intentional error
        return "No error"

    dash_duo.start_server(app, **start_server_kwargs)
    dash_duo.wait_for_text_to_equal("#output", "No error")
    dash_duo.find_element("#btn").click()
    dash_duo.wait_for_text_to_equal(dash_duo.devtools_error_count_locator, "1")


def get_error_html(dash_duo, index):
    # error is in an iframe so is annoying to read out - get it from the store
    return dash_duo.driver.execute_script(
        "return store.getState().error.backEnd[{}].error.html;".format(index)
    )


@pytest.mark.parametrize(
    "backend,fixture,start_server_kwargs, error_msg",
    [
        (
            "fastapi",
            "dash_duo",
            {
                "debug": True,
                "dev_tools_ui": True,
                "dev_tools_prune_errors": False,
                "reload": False,
            },
            "_fastapi.py",
        ),
        (
            "quart",
            "dash_duo_mp",
            {
                "debug": True,
                "use_reloader": False,
                "dev_tools_hot_reload": False,
                "dev_tools_prune_errors": False,
            },
            "_quart.py",
        ),
    ],
)
def test_backend_error_handling_no_prune(
    request, backend, fixture, start_server_kwargs, error_msg
):
    dash_duo = request.getfixturevalue(fixture)
    app = Dash(__name__, backend=backend)
    app.layout = html.Div(
        [html.Button(id="btn", children="Error", n_clicks=0), html.Div(id="output")]
    )

    @app.callback(Output("output", "children"), Input("btn", "n_clicks"))
    def error_callback(n):
        if n and n > 0:
            return 1 / 0  # Intentional error
        return "No error"

    dash_duo.start_server(app, **start_server_kwargs)
    dash_duo.wait_for_text_to_equal("#output", "No error")
    dash_duo.find_element("#btn").click()
    dash_duo.wait_for_text_to_equal(dash_duo.devtools_error_count_locator, "1")

    error0 = get_error_html(dash_duo, 0)
    assert "in error_callback" in error0
    assert "ZeroDivisionError" in error0
    assert "backends/" in error0 and error_msg in error0


@pytest.mark.parametrize(
    "backend,fixture,start_server_kwargs, error_msg",
    [
        ("fastapi", "dash_duo", {"debug": True, "reload": False}, "fastapi.py"),
        (
            "quart",
            "dash_duo_mp",
            {
                "debug": True,
                "use_reloader": False,
                "dev_tools_hot_reload": False,
            },
            "quart.py",
        ),
    ],
)
def test_backend_error_handling_prune(
    request, backend, fixture, start_server_kwargs, error_msg
):
    dash_duo = request.getfixturevalue(fixture)
    app = Dash(__name__, backend=backend)
    app.layout = html.Div(
        [html.Button(id="btn", children="Error", n_clicks=0), html.Div(id="output")]
    )

    @app.callback(Output("output", "children"), Input("btn", "n_clicks"))
    def error_callback(n):
        if n and n > 0:
            return 1 / 0  # Intentional error
        return "No error"

    dash_duo.start_server(app, **start_server_kwargs)
    dash_duo.wait_for_text_to_equal("#output", "No error")
    dash_duo.find_element("#btn").click()
    dash_duo.wait_for_text_to_equal(dash_duo.devtools_error_count_locator, "1")

    error0 = get_error_html(dash_duo, 0)
    assert "in error_callback" in error0
    assert "ZeroDivisionError" in error0
    assert "dash/backends/" not in error0 and error_msg not in error0


@pytest.mark.parametrize(
    "backend,fixture,input_value",
    [
        ("fastapi", "dash_duo", "Background FastAPI!"),
        ("quart", "dash_duo_mp", "Background Quart!"),
    ],
)
def test_backend_background_callback(request, backend, fixture, input_value):
    dash_duo = request.getfixturevalue(fixture)
    import diskcache

    cache = diskcache.Cache("./cache")
    from dash.background_callback import DiskcacheManager

    background_callback_manager = DiskcacheManager(cache)

    app = Dash(
        __name__,
        backend=backend,
        background_callback_manager=background_callback_manager,
    )
    app.layout = html.Div(
        [dcc.Input(id="input", value=input_value, type="text"), html.Div(id="output")]
    )

    @app.callback(
        Output("output", "children"), Input("input", "value"), background=True
    )
    def update_output_bg(value):
        return f"Background typed: {value}"

    dash_duo.start_server(app)
    dash_duo.wait_for_text_to_equal("#output", f"Background typed: {input_value}")
    dash_duo.clear_input(dash_duo.find_element("#input"))
    dash_duo.find_element("#input").send_keys(f"{backend.title()} BG Test")
    dash_duo.wait_for_text_to_equal(
        "#output", f"Background typed: {backend.title()} BG Test"
    )
    assert dash_duo.get_logs() == []


@pytest.mark.parametrize(
    "backend,expected_loggers",
    [
        ("flask", ["werkzeug"]),
        ("quart", ["hypercorn.access", "hypercorn.error"]),
        ("fastapi", ["uvicorn.access", "uvicorn.error"]),
    ],
)
def test_silence_routes_logging(backend, expected_loggers):
    """Test that route logging is silenced for all backends when dev_tools_silence_routes_logging is enabled."""
    app = Dash(__name__, backend=backend)
    app.layout = html.Div([html.Div(id="output", children="Test")])

    # Enable dev tools with silence_routes_logging
    app.enable_dev_tools(debug=True, dev_tools_silence_routes_logging=True)

    # Check that the expected loggers have been set to ERROR level
    for logger_name in expected_loggers:
        logger = logging.getLogger(logger_name)
        assert (
            logger.level == logging.ERROR
        ), f"Logger {logger_name} should be set to ERROR level for {backend} backend"


def test_fastapi_custom_post_route(dash_duo):
    """Test that user-defined POST routes work with FastAPI backend.

    Regression test for https://github.com/plotly/dash/issues/3801
    The DashMiddleware was consuming the request body for all routes,
    causing POST requests to user-defined routes to hang.
    """
    from fastapi import FastAPI, Request
    from fastapi.responses import JSONResponse
    import requests

    fastapi_app = FastAPI()

    @fastapi_app.get("/api/echo")
    async def echo_get():
        return JSONResponse({"method": "GET", "ok": True})

    @fastapi_app.post("/api/echo")
    async def echo_post(request: Request):
        body = await request.json()
        return JSONResponse({"echo": body})

    app = Dash(__name__, server=fastapi_app)
    app.layout = html.Div("Dash is running")

    dash_duo.start_server(app)

    # Test GET request
    url = dash_duo.server_url
    resp = requests.get(f"{url}/api/echo", timeout=5)
    assert resp.status_code == 200
    assert resp.json() == {"method": "GET", "ok": True}

    # Test POST request - this was hanging before the fix
    resp = requests.post(
        f"{url}/api/echo",
        json={"hello": "world"},
        timeout=5,
    )
    assert resp.status_code == 200
    assert resp.json() == {"echo": {"hello": "world"}}


def test_fastapi_catchall_request_context(dash_duo):
    """Test that non-Dash paths falling through to the catch-all route work.

    Regression test for https://github.com/plotly/dash/issues/3812
    The catch-all route renders ``dash_app.index()``, which needs a request
    context; without it the request raised ``RuntimeError: No active request in
    context`` and returned a 500.
    """
    import requests

    app = Dash(__name__, backend="fastapi")
    app.layout = html.Div("Dash is running")

    dash_duo.start_server(app)

    resp = requests.get(f"{dash_duo.server_url}/some/non-dash/path", timeout=5)
    assert resp.status_code == 200


def test_fastapi_run_forwards_reload_scope():
    """Forward reload include, exclude, and directory options to uvicorn."""
    import inspect
    import os
    from types import SimpleNamespace
    from unittest.mock import patch
    from fastapi import FastAPI
    from dash.backends._fastapi import FastAPIDashServer

    server = FastAPIDashServer(FastAPI())

    class DashApp:
        _dev_tools = {}

    app = DashApp()
    caller_frame = inspect.currentframe()
    stack_frame = SimpleNamespace(
        filename=os.path.join(os.getcwd(), "tests", "backend_tests", "test.py"),
        frame=caller_frame,
    )

    with patch("dash.backends._fastapi.subprocess.Popen") as popen, patch(
        "dash.backends._fastapi.inspect.stack", return_value=[None, None, stack_frame]
    ):
        server.run(
            dash_app=app,
            host="127.0.0.1",
            port=8050,
            debug=False,
            reload=True,
            reload_dirs=["app", "src"],
            reload_excludes=["tests/*"],
            reload_includes=["*.py"],
        )

    args = popen.call_args.args[0]
    assert args[-9:] == [
        "--reload",
        "--reload-dir",
        "app",
        "--reload-dir",
        "src",
        "--reload-exclude",
        "tests/*",
        "--reload-include",
        "*.py",
    ]
    popen.return_value.wait.assert_called_once_with()
