from helpdesk import create_ticket, list_tickets
create_ticket("Не работает турникет на входе", "Дмитрий")
create_ticket("Пропала сеть в кабинете 320", "Татьяна", "Проблема с интернетом")
print(list_tickets("Дмитрий"))
print(list_tickets("Татьяна"))